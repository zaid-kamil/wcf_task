package com.wipro.candidate.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static Connection getDBConn() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(Constants.ORCL_URL, Constants.USERNAME, Constants.PASSWORD);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
