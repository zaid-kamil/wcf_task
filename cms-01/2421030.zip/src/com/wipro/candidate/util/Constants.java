package com.wipro.candidate.util;

public class Constants {
	private static String BATCH_NUM = "202421";
	private static String PBLAPP_ID = "2421030";
	public static final String ORCL_URL = "jdbc:oracle:thin:@localhost:1521:XE";
	public static final String SQLITE_URL = "jdbc:sqlite:cms01.sqlite3";
	public static final String USERNAME = "B"+BATCH_NUM+PBLAPP_ID;
	public static final String PASSWORD = "B"+BATCH_NUM+PBLAPP_ID;
}
